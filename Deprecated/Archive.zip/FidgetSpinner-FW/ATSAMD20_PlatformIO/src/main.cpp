#include <main.hpp>

//Interrupts
void onIntButton() {}
void onIntIR() {}
ISR(WDT_vect) {}

void setup() {
}

void loop() {
}