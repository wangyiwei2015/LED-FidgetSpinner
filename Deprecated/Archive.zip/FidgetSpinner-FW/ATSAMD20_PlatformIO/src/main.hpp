#ifndef _MAIN_HPP
#define _MAIN_HPP

#include <Arduino.h>

#include <Defs/consts.hpp>
#include <Defs/pins.hpp>
#include <Power/Power.hpp>

#endif